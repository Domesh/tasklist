var require = meteorInstall({"lib":{"collections.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// lib/collections.js                                                          //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({                                                                // 1
  Notes: function () {                                                         // 1
    return Notes;                                                              // 1
  }                                                                            // 1
});                                                                            // 1
var Mongo = void 0;                                                            // 1
module.watch(require("meteor/mongo"), {                                        // 1
  Mongo: function (v) {                                                        // 1
    Mongo = v;                                                                 // 1
  }                                                                            // 1
}, 0);                                                                         // 1
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
  Meteor: function (v) {                                                       // 1
    Meteor = v;                                                                // 1
  }                                                                            // 1
}, 1);                                                                         // 1
var check = void 0;                                                            // 1
module.watch(require("meteor/check"), {                                        // 1
  check: function (v) {                                                        // 1
    check = v;                                                                 // 1
  }                                                                            // 1
}, 2);                                                                         // 1
var Notes = new Mongo.Collection('notes');                                     // 5
Meteor.methods({                                                               // 7
  'notes.insert': function (text) {                                            // 8
    check(text, String); // check user is logged in                            // 9
                                                                               //
    if (!Meteor.userId()) {                                                    // 13
      throw new Meteor.Error('not-authorized');                                // 14
    }                                                                          // 15
                                                                               //
    Notes.insert({                                                             // 17
      text: text,                                                              // 18
      cerateAt: new Date(),                                                    // 19
      owner: Meteor.userId(),                                                  // 20
      username: Meteor.user().username                                         // 21
    });                                                                        // 17
  },                                                                           // 23
  'notes.remove': function (note) {                                            // 24
    check(note._id, String);                                                   // 25
                                                                               //
    if (note.owner !== Meteor.userId()) {                                      // 28
      throw new Meteor.Error('not-authorized');                                // 29
    }                                                                          // 30
                                                                               //
    Notes.remove(note._id);                                                    // 32
  }                                                                            // 33
});                                                                            // 7
/////////////////////////////////////////////////////////////////////////////////

}},"deploy-tasklist":{"mup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// deploy-tasklist/mup.js                                                      //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.exports = {                                                             // 1
  servers: {                                                                   // 2
    one: {                                                                     // 3
      // TODO: set host address, username, and authentication method           // 4
      host: '139.59.80.233',                                                   // 5
      username: 'root' // pem: './path/to/pem'                                 // 6
      // password: 'server-password'                                           // 8
      // or neither for authenticate from ssh-agent                            // 9
                                                                               //
    }                                                                          // 3
  },                                                                           // 2
  app: {                                                                       // 13
    // TODO: change app name and path                                          // 14
    name: 'tasklist',                                                          // 15
    path: '../',                                                               // 16
    servers: {                                                                 // 18
      one: {}                                                                  // 19
    },                                                                         // 18
    buildOptions: {                                                            // 22
      serverOnly: true                                                         // 23
    },                                                                         // 22
    env: {                                                                     // 26
      // TODO: Change to your app's url                                        // 27
      // If you are using ssl, it needs to start with https://                 // 28
      ROOT_URL: 'http://tasklist.com',                                         // 29
      MONGO_URL: 'mongodb://localhost/meteor'                                  // 30
    },                                                                         // 26
    // ssl: { // (optional)                                                    // 33
    //   // Enables let's encrypt (optional)                                   // 34
    //   autogenerate: {                                                       // 35
    //     email: 'email.address@domain.com',                                  // 36
    //     // comma separated list of domains                                  // 37
    //     domains: 'website.com,www.website.com'                              // 38
    //   }                                                                     // 39
    // },                                                                      // 40
    docker: {                                                                  // 42
      // change to 'kadirahq/meteord' if your app is using Meteor 1.3 or older
      image: 'abernix/meteord:base'                                            // 44
    },                                                                         // 42
    // Show progress bar while uploading bundle to server                      // 47
    // You might need to disable it on CI servers                              // 48
    enableUploadProgressBar: true                                              // 49
  },                                                                           // 13
  mongo: {                                                                     // 52
    version: '3.4.1',                                                          // 53
    servers: {                                                                 // 54
      one: {}                                                                  // 55
    }                                                                          // 54
  }                                                                            // 52
};                                                                             // 1
/////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// server/main.js                                                              //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
  Meteor: function (v) {                                                       // 1
    Meteor = v;                                                                // 1
  }                                                                            // 1
}, 0);                                                                         // 1
Meteor.startup(function () {// code to run on server at startup                // 3
});                                                                            // 5
/////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/collections.js");
require("./deploy-tasklist/mup.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
